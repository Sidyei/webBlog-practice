import express from "express";
import { v4 as uuidv4 } from 'uuid';
const router = express.Router();

let users = [];

router.post("/", (req, res, next) => {
  const user = req.body;
  users.push( {...user, id: uuidv4() } );
  res.send(`${user.first_name} has been added to the database`);
});

router.get("/list", (req, res) => {
  res.send(users);
});

router.get("/:id", (req, res) => {
  const { id } = req.params;
  const foundUser = users.find((user) =>  user.id === id );
  const nameme = foundUser.first_name;
  res.send(nameme);
});

router.delete("/:id", (req, res) => {
  const { id } = req.params;

  users = users.filter((user) => user.id !== id);

  res.send(`${id} deleted successfully`)
});

router.patch("/:id", (req, res) => {
  const { id } = req.params;
  const user = users.find((user) => user.id === id);
  const { first_name } = req.body;

  if(first_name) {
    user.first_name = first_name;
  }

  res.send(`User with the id ${id} has been updated`);
});

export default router;

