import express from "express";
import bodyParser from "body-parser";
import userRouter from "./routes/users.js";
import { v4 as uuidv4} from "uuid"
import methodOverride from "method-override"

const app = express();
const port = 3000;


app.use(bodyParser.urlencoded({extended : true}));
app.use(express.static("public"));

app.use(methodOverride('X-HTTP-Method-Override'));
app.use(methodOverride("_method"));

let inputs = [];

app.get("/", (req, res) => {
  res.render("index.ejs", { inputs });
});

app.get("/blogs/createBlog", (req, res) => {
  res.render("createBlog.ejs");
});

app.post("/blogs", (req, res) => {
  const newBlog = { ...req.body, id: uuidv4() };
  inputs.push(newBlog);

  res.redirect("/blogs/createBlog");
});

app.delete("/blogs/:id", (req, res) => {
  const { id } = req.params;
  inputs = inputs.filter(b => b.id !== id );
  res.redirect("/");
  console.log(`Id: ${id} successfully deleted`)
});

app.get("/blogs/user/:id", (req, res) => {
  const { id } = req.params;
  const blog = inputs.find((b) => b.id === id);
  res.render("about.ejs", {
    blog: blog,
    inpute: inputs.length
  });
  console.log(blog);
});

// Header Routes
app.get("/user", (req, res) => {
  res.render("about.ejs");
})

app.get("/createBlog", (req, res) => {
  res.render("createBlog.ejs");
})

app.use("/users", userRouter);

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});